import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');
  const history = useHistory();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/login', {
        email: email,
        password: password
      });
      if (response.data.success) {
        // Redirect user to the dashboard or any other desired page upon successful login
        history.push("/");
      } else {
        setMsg(response.data.message);
      }
    } catch (error) {
      console.error('Error:', error);
      setMsg('An error occurred. Please try again.');
    }
  };

  return (
    <section className="hero has-background-grey-light is-fullheight is-fullwidth">
      <div className="hero-body">
        <div className="container">
          <div className="columns is-centered">
            <div className="column is-4-desktop">
              <form className="box" onSubmit={handleLogin}>
                <div className="field mt-5">
                  <label className="label">Email</label>
                  <div className="control">
                    <input 
                      type="text" 
                      className="input" 
                      placeholder="Email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <div className="field mt-5">
                  <label className="label">Password</label>
                  <div className="control">
                    <input 
                      type="password" 
                      className="input" 
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <div className="field mt-5">
                  <button type="submit" className="button is-success is-fullwidth">Login</button>
                </div>
                {msg && <p className="error-message">{msg}</p>}
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Login;
