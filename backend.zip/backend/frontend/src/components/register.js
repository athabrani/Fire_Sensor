import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import axios from 'axios';

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [confPassword, setConfPassword] = useState('');
  const [msg, setMsg] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const history = useHistory();

  const handleRegister = async (e) => {
    e.preventDefault();
    if (password !== confPassword) {
      setPasswordError('Passwords do not match');
      return;
    }
    try {
      await axios.post('http://localhost:5000/users', {
        name: name,
        email: email,
        phoneNumber: phoneNumber,
        password: password,
        confPassword: confPassword
      });
      history.push("/");
    } catch (error) {
      if (error.response) {
        setMsg(error.response.data.msg);
        // Handle error response
      }
    }
  };

  return (
    <section className="hero has-background-grey-light is-fullheight is-fullwidth">
      <div className="hero-body">
        <div className="container">
          <div className="columns is-centered">
            <div className="column is-4-desktop">
              <form className="box" onSubmit={handleRegister}>
                <div className="field mt-5">
                  <label className="label">Name</label>
                  <div className="control">
                    <input 
                      type="text" 
                      className="input" 
                      placeholder="Name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>
                </div>
                {/* Other input fields */}
                <div className="field mt-5">
                  <label className="label">Password</label>
                  <div className="control">
                    <input 
                      type="password" 
                      className="input" 
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <div className="field mt-5">
                  <label className="label">Confirm Password</label>
                  <div className="control">
                    <input 
                      type="password" 
                      className="input" 
                      placeholder="Confirm Password"
                      value={confPassword}
                      onChange={(e) => setConfPassword(e.target.value)}
                      required
                    />
                  </div>
                  {passwordError && <p className="help is-danger">{passwordError}</p>}
                </div>
                <div className="field mt-5">
                  <button type="submit" className="button is-success is-fullwidth">Register</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Register;
