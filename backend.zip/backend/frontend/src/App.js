import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom'; // Perbaikan: Mengimpor BrowserRouter
import Dashboard from "./components/dashboard";
import Login from "./components/Login";
import Navbar from "./components/navbar";
import Register from "./components/register";

function App() {
  return (
    <BrowserRouter> {/* Perbaikan: Menggunakan BrowserRouter */}
      <Switch>
        <Route exact path="/">
          <Login />
        </Route>
        <Route path="/register">
          <Register />
        </Route>
        <Route path="/dashboard">
          <Navbar />
          <Dashboard />
        </Route>
      </Switch>
    </BrowserRouter>
  );
}

export default App;